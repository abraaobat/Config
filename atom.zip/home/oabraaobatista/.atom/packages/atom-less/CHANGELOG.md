## 0.1.0 - First Release
* Initial Release - Matching functionality to less-autocompile package
* Include support for LESS plugins - Clean-CSS and AutoPrefixer
