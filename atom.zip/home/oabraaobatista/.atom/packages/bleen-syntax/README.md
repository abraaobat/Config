# Bleen-syntax theme

A deep but soft green/blue syntax theme.

![Bleen-syntax](http://i.imgur.com/8WP67uw.png)

> Bleen syntax with Atom one dark theme. The font used is Fira Code.
