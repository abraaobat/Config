## 0.4.3
* Add Image Live option.
* Remove JS Live option.

## 0.4.0
* Add an option for delay before refreshing web page.

## 0.3.0
* Works with Atom 1.0
* Supports some preferences

## 0.1.0 - First Release
* Enable to turn on/off LiveReload server
