# less-build

An Atom builder plugin for LESS files.

# Configuration

Configure the package as:
```
"less-build":
    "project": "project-folder-name"
    "options":
      "app/src/app.less": "app/build/src/app.css"
      "lib/src/lib.less": "lib/build/src/lib.css"
```
