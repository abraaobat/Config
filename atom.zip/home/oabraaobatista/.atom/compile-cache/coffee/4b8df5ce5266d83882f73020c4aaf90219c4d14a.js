(function() {
  var OutputWriter, async, fs, mkdirp, path;

  fs = require('fs');

  path = require('path');

  mkdirp = require('mkdirp');

  async = require('async');

  OutputWriter = (function() {
    function OutputWriter() {}

    OutputWriter.prototype.write = function(output, options) {
      var cssFile, sourceMapFile, _ref;
      _ref = this.getDestination(options), cssFile = _ref[0], sourceMapFile = _ref[1];
      return async.series({
        css: (function(_this) {
          return function(callback) {
            return _this.writeFile(cssFile, output.css, callback);
          };
        })(this),
        map: (function(_this) {
          return function(callback) {
            if (output.map != null) {
              return _this.writeFile(sourceMapFile, output.map, callback);
            } else {
              return callback(null);
            }
          };
        })(this)
      }, function(err, results) {
        if (err) {
          return atom.notifications.addError(err, {
            dismissiable: true
          });
        } else if (output.map != null) {
          return atom.notifications.addSuccess("Files created");
        } else {
          return atom.notifications.addSuccess("File created");
        }
      });
    };

    OutputWriter.prototype.writeFile = function(file, content, callback) {
      return mkdirp(path.dirname(file), function(err) {
        if (err) {
          return atom.notifications.addError(err, {
            dismissiable: true
          });
        } else {
          return fs.writeFile(file, content, callback);
        }
      });
    };

    OutputWriter.prototype.getDestination = function(options) {
      var cssFile, lessDir, lessFile, sourceMapFile;
      lessFile = path.basename(options.file, '.less');
      lessDir = path.dirname(options.file);
      if (typeof options.out === 'string') {
        cssFile = options.out;
      } else {
        cssFile = lessFile + '.css';
      }
      cssFile = path.resolve(lessDir, cssFile);
      if (options.sourceMap != null) {
        sourceMapFile = "" + cssFile + ".map";
        sourceMapFile = path.resolve(lessDir, sourceMapFile);
      }
      return [cssFile, sourceMapFile];
    };

    return OutputWriter;

  })();

  module.exports = new OutputWriter;

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvYXRvbS1sZXNzL2xpYi9vdXRwdXQtd3JpdGVyLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSxxQ0FBQTs7QUFBQSxFQUFBLEVBQUEsR0FBSyxPQUFBLENBQVEsSUFBUixDQUFMLENBQUE7O0FBQUEsRUFDQSxJQUFBLEdBQU8sT0FBQSxDQUFRLE1BQVIsQ0FEUCxDQUFBOztBQUFBLEVBRUEsTUFBQSxHQUFTLE9BQUEsQ0FBUSxRQUFSLENBRlQsQ0FBQTs7QUFBQSxFQUdBLEtBQUEsR0FBUSxPQUFBLENBQVEsT0FBUixDQUhSLENBQUE7O0FBQUEsRUFLTTs4QkFDRjs7QUFBQSwyQkFBQSxLQUFBLEdBQU8sU0FBQyxNQUFELEVBQVMsT0FBVCxHQUFBO0FBQ0gsVUFBQSw0QkFBQTtBQUFBLE1BQUEsT0FBMkIsSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsT0FBaEIsQ0FBM0IsRUFBQyxpQkFBRCxFQUFVLHVCQUFWLENBQUE7YUFFQSxLQUFLLENBQUMsTUFBTixDQUNJO0FBQUEsUUFBQSxHQUFBLEVBQUssQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFDLFFBQUQsR0FBQTttQkFDRCxLQUFDLENBQUEsU0FBRCxDQUFXLE9BQVgsRUFBb0IsTUFBTSxDQUFDLEdBQTNCLEVBQWdDLFFBQWhDLEVBREM7VUFBQSxFQUFBO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFMO0FBQUEsUUFFQSxHQUFBLEVBQUssQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFDLFFBQUQsR0FBQTtBQUNELFlBQUEsSUFBRyxrQkFBSDtxQkFDSSxLQUFDLENBQUEsU0FBRCxDQUFXLGFBQVgsRUFBMEIsTUFBTSxDQUFDLEdBQWpDLEVBQXNDLFFBQXRDLEVBREo7YUFBQSxNQUFBO3FCQUdJLFFBQUEsQ0FBUyxJQUFULEVBSEo7YUFEQztVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRkw7T0FESixFQVFNLFNBQUMsR0FBRCxFQUFNLE9BQU4sR0FBQTtBQUNFLFFBQUEsSUFBRyxHQUFIO2lCQUNJLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsR0FBNUIsRUFDSTtBQUFBLFlBQUEsWUFBQSxFQUFjLElBQWQ7V0FESixFQURKO1NBQUEsTUFHSyxJQUFHLGtCQUFIO2lCQUNELElBQUksQ0FBQyxhQUFhLENBQUMsVUFBbkIsQ0FBOEIsZUFBOUIsRUFEQztTQUFBLE1BQUE7aUJBR0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFuQixDQUE4QixjQUE5QixFQUhDO1NBSlA7TUFBQSxDQVJOLEVBSEc7SUFBQSxDQUFQLENBQUE7O0FBQUEsMkJBb0JBLFNBQUEsR0FBVyxTQUFDLElBQUQsRUFBTyxPQUFQLEVBQWdCLFFBQWhCLEdBQUE7YUFDUCxNQUFBLENBQU8sSUFBSSxDQUFDLE9BQUwsQ0FBYSxJQUFiLENBQVAsRUFBMkIsU0FBQyxHQUFELEdBQUE7QUFDdkIsUUFBQSxJQUFHLEdBQUg7aUJBQ0ksSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0QixHQUE1QixFQUNJO0FBQUEsWUFBQSxZQUFBLEVBQWMsSUFBZDtXQURKLEVBREo7U0FBQSxNQUFBO2lCQUlJLEVBQUUsQ0FBQyxTQUFILENBQWEsSUFBYixFQUFtQixPQUFuQixFQUE0QixRQUE1QixFQUpKO1NBRHVCO01BQUEsQ0FBM0IsRUFETztJQUFBLENBcEJYLENBQUE7O0FBQUEsMkJBNEJBLGNBQUEsR0FBZ0IsU0FBQyxPQUFELEdBQUE7QUFDWixVQUFBLHlDQUFBO0FBQUEsTUFBQSxRQUFBLEdBQVcsSUFBSSxDQUFDLFFBQUwsQ0FBYyxPQUFPLENBQUMsSUFBdEIsRUFBNEIsT0FBNUIsQ0FBWCxDQUFBO0FBQUEsTUFDQSxPQUFBLEdBQVUsSUFBSSxDQUFDLE9BQUwsQ0FBYSxPQUFPLENBQUMsSUFBckIsQ0FEVixDQUFBO0FBR0EsTUFBQSxJQUFHLE1BQUEsQ0FBQSxPQUFjLENBQUMsR0FBZixLQUFzQixRQUF6QjtBQUNJLFFBQUEsT0FBQSxHQUFVLE9BQU8sQ0FBQyxHQUFsQixDQURKO09BQUEsTUFBQTtBQUdJLFFBQUEsT0FBQSxHQUFVLFFBQUEsR0FBVyxNQUFyQixDQUhKO09BSEE7QUFBQSxNQVFBLE9BQUEsR0FBVSxJQUFJLENBQUMsT0FBTCxDQUFhLE9BQWIsRUFBc0IsT0FBdEIsQ0FSVixDQUFBO0FBVUEsTUFBQSxJQUFHLHlCQUFIO0FBQ0ksUUFBQSxhQUFBLEdBQWdCLEVBQUEsR0FBRyxPQUFILEdBQVcsTUFBM0IsQ0FBQTtBQUFBLFFBQ0EsYUFBQSxHQUFnQixJQUFJLENBQUMsT0FBTCxDQUFhLE9BQWIsRUFBc0IsYUFBdEIsQ0FEaEIsQ0FESjtPQVZBO0FBY0EsYUFBTyxDQUFDLE9BQUQsRUFBVSxhQUFWLENBQVAsQ0FmWTtJQUFBLENBNUJoQixDQUFBOzt3QkFBQTs7TUFOSixDQUFBOztBQUFBLEVBbURBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLEdBQUEsQ0FBQSxZQW5EakIsQ0FBQTtBQUFBIgp9

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/atom-less/lib/output-writer.coffee
