(function() {
  var FirstLine, fs, less, lessPlugins, outputWriter, path;

  fs = require('fs');

  path = require('path');

  FirstLine = require('./firstline');

  less = require('less');

  lessPlugins = require('./less-plugins');

  outputWriter = require('./output-writer');

  module.exports = {
    render: function(filepath) {
      return this.getOptions(filepath, this.renderLess);
    },
    renderLess: (function(_this) {
      return function(options) {
        var lessOptions;
        if (!options.out) {
          return;
        }
        lessOptions = {
          filename: options.file
        };
        if ((options.compress != null) && (options.sourceMap == null) && (options.cleancss == null)) {
          lessOptions.compress = true;
        } else if ((options.sourceMap != null) && (options.cleancss == null)) {
          lessOptions.sourceMap = typeof options.sourceMap === 'object' ? options.sourceMap : {};
        }
        lessPlugins(options, lessOptions);
        return fs.readFile(options.file, function(err, contents) {
          if (err) {
            return console.log(err);
          }
          return less.render(contents.toString(), lessOptions).then(function(output) {
            return outputWriter.write(output, options);
          }, function(err) {
            return atom.notifications.addError(err.message, {
              detail: "" + err.filename + ":" + err.line,
              dismissable: true
            });
          });
        });
      };
    })(this),
    getOptions: function(filepath, callback) {
      var fl;
      fl = new FirstLine;
      return fl.read(filepath, (function(_this) {
        return function(err, line) {
          var i, options, _i, _ref, _results;
          if (err) {
            atom.notifications.addError("" + filepath + " does not exist", {
              dismissable: true
            });
            return;
          }
          options = _this.parseFirstLine(filepath, line);
          if (options.main) {
            if (typeof options.main === 'string') {
              return _this.getOptions(path.resolve(path.dirname(filepath), options.main), callback);
            } else {
              _results = [];
              for (i = _i = 0, _ref = options.main.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
                _results.push(_this.getOptions(path.resolve(path.dirname(filepath), options.main[i]), callback));
              }
              return _results;
            }
          } else {
            return callback(options);
          }
        };
      })(this));
    },
    parseFirstLine: function(filepath, line) {
      var match, options;
      match = /^\s*\/\/\s*(.*)/.exec(line);
      if (!match) {
        options = {};
      } else {
        try {
          options = JSON.parse('{' + match[1] + '}');
        } catch (_error) {
          atom.notifications.addError('Cat\'t find LESS options in comment', {
            detail: 'The LESS options must be a valid JSON comment in the first line of the LESS file',
            dismissable: true
          });
          options = {};
        }
      }
      options.file = filepath;
      return options;
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvYXRvbS1sZXNzL2xpYi9sZXNzLXJlbmRlcmVyLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSxvREFBQTs7QUFBQSxFQUFBLEVBQUEsR0FBSyxPQUFBLENBQVEsSUFBUixDQUFMLENBQUE7O0FBQUEsRUFDQSxJQUFBLEdBQU8sT0FBQSxDQUFRLE1BQVIsQ0FEUCxDQUFBOztBQUFBLEVBRUEsU0FBQSxHQUFZLE9BQUEsQ0FBUSxhQUFSLENBRlosQ0FBQTs7QUFBQSxFQUdBLElBQUEsR0FBTyxPQUFBLENBQVEsTUFBUixDQUhQLENBQUE7O0FBQUEsRUFJQSxXQUFBLEdBQWMsT0FBQSxDQUFRLGdCQUFSLENBSmQsQ0FBQTs7QUFBQSxFQUtBLFlBQUEsR0FBZSxPQUFBLENBQVEsaUJBQVIsQ0FMZixDQUFBOztBQUFBLEVBT0EsTUFBTSxDQUFDLE9BQVAsR0FDSTtBQUFBLElBQUEsTUFBQSxFQUFRLFNBQUMsUUFBRCxHQUFBO2FBQ0osSUFBQyxDQUFBLFVBQUQsQ0FBWSxRQUFaLEVBQXNCLElBQUMsQ0FBQSxVQUF2QixFQURJO0lBQUEsQ0FBUjtBQUFBLElBR0EsVUFBQSxFQUFZLENBQUEsU0FBQSxLQUFBLEdBQUE7YUFBQSxTQUFDLE9BQUQsR0FBQTtBQUNSLFlBQUEsV0FBQTtBQUFBLFFBQUEsSUFBVSxDQUFBLE9BQVcsQ0FBQyxHQUF0QjtBQUFBLGdCQUFBLENBQUE7U0FBQTtBQUFBLFFBRUEsV0FBQSxHQUNJO0FBQUEsVUFBQSxRQUFBLEVBQVUsT0FBTyxDQUFDLElBQWxCO1NBSEosQ0FBQTtBQUtBLFFBQUEsSUFBRywwQkFBQSxJQUEwQiwyQkFBMUIsSUFBcUQsMEJBQXhEO0FBQ0ksVUFBQSxXQUFXLENBQUMsUUFBWixHQUF1QixJQUF2QixDQURKO1NBQUEsTUFFSyxJQUFHLDJCQUFBLElBQTJCLDBCQUE5QjtBQUNELFVBQUEsV0FBVyxDQUFDLFNBQVosR0FBMkIsTUFBQSxDQUFBLE9BQWMsQ0FBQyxTQUFmLEtBQTRCLFFBQS9CLEdBQTZDLE9BQU8sQ0FBQyxTQUFyRCxHQUFvRSxFQUE1RixDQURDO1NBUEw7QUFBQSxRQVVBLFdBQUEsQ0FBWSxPQUFaLEVBQXFCLFdBQXJCLENBVkEsQ0FBQTtlQVlBLEVBQUUsQ0FBQyxRQUFILENBQVksT0FBTyxDQUFDLElBQXBCLEVBQTBCLFNBQUMsR0FBRCxFQUFNLFFBQU4sR0FBQTtBQUN0QixVQUFBLElBQTBCLEdBQTFCO0FBQUEsbUJBQU8sT0FBTyxDQUFDLEdBQVIsQ0FBWSxHQUFaLENBQVAsQ0FBQTtXQUFBO2lCQUVBLElBQUksQ0FBQyxNQUFMLENBQVksUUFBUSxDQUFDLFFBQVQsQ0FBQSxDQUFaLEVBQWlDLFdBQWpDLENBQ0ksQ0FBQyxJQURMLENBQ1UsU0FBQyxNQUFELEdBQUE7bUJBQ0YsWUFBWSxDQUFDLEtBQWIsQ0FBbUIsTUFBbkIsRUFBMkIsT0FBM0IsRUFERTtVQUFBLENBRFYsRUFHTSxTQUFDLEdBQUQsR0FBQTttQkFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLEdBQUcsQ0FBQyxPQUFoQyxFQUNJO0FBQUEsY0FBQSxNQUFBLEVBQVEsRUFBQSxHQUFHLEdBQUcsQ0FBQyxRQUFQLEdBQWdCLEdBQWhCLEdBQW1CLEdBQUcsQ0FBQyxJQUEvQjtBQUFBLGNBQ0EsV0FBQSxFQUFhLElBRGI7YUFESixFQURGO1VBQUEsQ0FITixFQUhzQjtRQUFBLENBQTFCLEVBYlE7TUFBQSxFQUFBO0lBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUhaO0FBQUEsSUEyQkEsVUFBQSxFQUFZLFNBQUMsUUFBRCxFQUFXLFFBQVgsR0FBQTtBQUNSLFVBQUEsRUFBQTtBQUFBLE1BQUEsRUFBQSxHQUFLLEdBQUEsQ0FBQSxTQUFMLENBQUE7YUFDQSxFQUFFLENBQUMsSUFBSCxDQUFRLFFBQVIsRUFBa0IsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsR0FBRCxFQUFNLElBQU4sR0FBQTtBQUNkLGNBQUEsOEJBQUE7QUFBQSxVQUFBLElBQUcsR0FBSDtBQUNJLFlBQUEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0QixFQUFBLEdBQUcsUUFBSCxHQUFZLGlCQUF4QyxFQUNJO0FBQUEsY0FBQSxXQUFBLEVBQWEsSUFBYjthQURKLENBQUEsQ0FBQTtBQUVBLGtCQUFBLENBSEo7V0FBQTtBQUFBLFVBS0EsT0FBQSxHQUFVLEtBQUMsQ0FBQSxjQUFELENBQWdCLFFBQWhCLEVBQTBCLElBQTFCLENBTFYsQ0FBQTtBQU9BLFVBQUEsSUFBRyxPQUFPLENBQUMsSUFBWDtBQUNJLFlBQUEsSUFBRyxNQUFBLENBQUEsT0FBYyxDQUFDLElBQWYsS0FBdUIsUUFBMUI7cUJBQ0ksS0FBQyxDQUFBLFVBQUQsQ0FBWSxJQUFJLENBQUMsT0FBTCxDQUFhLElBQUksQ0FBQyxPQUFMLENBQWEsUUFBYixDQUFiLEVBQXFDLE9BQU8sQ0FBQyxJQUE3QyxDQUFaLEVBQWdFLFFBQWhFLEVBREo7YUFBQSxNQUFBO0FBR0k7bUJBQVMsc0dBQVQsR0FBQTtBQUNJLDhCQUFBLEtBQUMsQ0FBQSxVQUFELENBQVksSUFBSSxDQUFDLE9BQUwsQ0FBYSxJQUFJLENBQUMsT0FBTCxDQUFhLFFBQWIsQ0FBYixFQUFxQyxPQUFPLENBQUMsSUFBSyxDQUFBLENBQUEsQ0FBbEQsQ0FBWixFQUFtRSxRQUFuRSxFQUFBLENBREo7QUFBQTs4QkFISjthQURKO1dBQUEsTUFBQTttQkFRSSxRQUFBLENBQVMsT0FBVCxFQVJKO1dBUmM7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFsQixFQUZRO0lBQUEsQ0EzQlo7QUFBQSxJQStDQSxjQUFBLEVBQWdCLFNBQUMsUUFBRCxFQUFXLElBQVgsR0FBQTtBQUNaLFVBQUEsY0FBQTtBQUFBLE1BQUEsS0FBQSxHQUFRLGlCQUFpQixDQUFDLElBQWxCLENBQXVCLElBQXZCLENBQVIsQ0FBQTtBQUNBLE1BQUEsSUFBRyxDQUFBLEtBQUg7QUFDSSxRQUFBLE9BQUEsR0FBVSxFQUFWLENBREo7T0FBQSxNQUFBO0FBR0k7QUFDSSxVQUFBLE9BQUEsR0FBVSxJQUFJLENBQUMsS0FBTCxDQUFXLEdBQUEsR0FBTSxLQUFNLENBQUEsQ0FBQSxDQUFaLEdBQWlCLEdBQTVCLENBQVYsQ0FESjtTQUFBLGNBQUE7QUFHSSxVQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIscUNBQTVCLEVBQ0k7QUFBQSxZQUFBLE1BQUEsRUFBUSxrRkFBUjtBQUFBLFlBQ0EsV0FBQSxFQUFhLElBRGI7V0FESixDQUFBLENBQUE7QUFBQSxVQUdBLE9BQUEsR0FBVSxFQUhWLENBSEo7U0FISjtPQURBO0FBQUEsTUFZQSxPQUFPLENBQUMsSUFBUixHQUFlLFFBWmYsQ0FBQTthQWFBLFFBZFk7SUFBQSxDQS9DaEI7R0FSSixDQUFBO0FBQUEiCn0=

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/atom-less/lib/less-renderer.coffee
