(function() {
  var CompositeDisposable, renderer;

  CompositeDisposable = require('atom').CompositeDisposable;

  renderer = require('./less-renderer');

  module.exports = {
    activate: function(state) {
      this.subscriptions = new CompositeDisposable;
      return this.subscriptions.add(atom.commands.add('atom-workspace', {
        'core:save': (function(_this) {
          return function() {
            return _this.render();
          };
        })(this)
      }));
    },
    deactivate: function() {
      return this.subscriptions.dispose();
    },
    serialize: function() {},
    render: function() {
      var editor, filepath, grammer;
      editor = atom.workspace.getActiveTextEditor();
      if (!editor) {
        return;
      }
      grammer = editor.getGrammar();
      if (grammer.name.toLowerCase() !== 'less') {
        return;
      }
      filepath = editor.getPath();
      return renderer.render(filepath);
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvYXRvbS1sZXNzL2xpYi9hdG9tLWxlc3MuY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQUE7QUFBQSxNQUFBLDZCQUFBOztBQUFBLEVBQUMsc0JBQXVCLE9BQUEsQ0FBUSxNQUFSLEVBQXZCLG1CQUFELENBQUE7O0FBQUEsRUFFQSxRQUFBLEdBQVcsT0FBQSxDQUFRLGlCQUFSLENBRlgsQ0FBQTs7QUFBQSxFQUlBLE1BQU0sQ0FBQyxPQUFQLEdBQ0k7QUFBQSxJQUFBLFFBQUEsRUFBVSxTQUFDLEtBQUQsR0FBQTtBQUNOLE1BQUEsSUFBQyxDQUFBLGFBQUQsR0FBaUIsR0FBQSxDQUFBLG1CQUFqQixDQUFBO2FBRUEsSUFBQyxDQUFBLGFBQWEsQ0FBQyxHQUFmLENBQW1CLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFDZjtBQUFBLFFBQUEsV0FBQSxFQUFhLENBQUEsU0FBQSxLQUFBLEdBQUE7aUJBQUEsU0FBQSxHQUFBO21CQUFHLEtBQUMsQ0FBQSxNQUFELENBQUEsRUFBSDtVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWI7T0FEZSxDQUFuQixFQUhNO0lBQUEsQ0FBVjtBQUFBLElBTUEsVUFBQSxFQUFZLFNBQUEsR0FBQTthQUNSLElBQUMsQ0FBQSxhQUFhLENBQUMsT0FBZixDQUFBLEVBRFE7SUFBQSxDQU5aO0FBQUEsSUFTQSxTQUFBLEVBQVcsU0FBQSxHQUFBLENBVFg7QUFBQSxJQVdBLE1BQUEsRUFBUSxTQUFBLEdBQUE7QUFDSixVQUFBLHlCQUFBO0FBQUEsTUFBQSxNQUFBLEdBQVMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBZixDQUFBLENBQVQsQ0FBQTtBQUNBLE1BQUEsSUFBVSxDQUFBLE1BQVY7QUFBQSxjQUFBLENBQUE7T0FEQTtBQUFBLE1BR0EsT0FBQSxHQUFVLE1BQU0sQ0FBQyxVQUFQLENBQUEsQ0FIVixDQUFBO0FBSUEsTUFBQSxJQUFVLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBYixDQUFBLENBQUEsS0FBOEIsTUFBeEM7QUFBQSxjQUFBLENBQUE7T0FKQTtBQUFBLE1BTUEsUUFBQSxHQUFXLE1BQU0sQ0FBQyxPQUFQLENBQUEsQ0FOWCxDQUFBO2FBT0EsUUFBUSxDQUFDLE1BQVQsQ0FBZ0IsUUFBaEIsRUFSSTtJQUFBLENBWFI7R0FMSixDQUFBO0FBQUEiCn0=

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/atom-less/lib/atom-less.coffee
