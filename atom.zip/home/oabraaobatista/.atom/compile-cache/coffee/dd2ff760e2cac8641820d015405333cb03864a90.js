(function() {
  var LessCompilerProcess;

  module.exports = LessCompilerProcess = (function() {
    function LessCompilerProcess() {}

    LessCompilerProcess.prototype.initialize = function() {
      this.inProgress = false;
      return atom.commands.add('atom-workspace', {
        'core:save': (function(_this) {
          return function(e) {
            if (!_this.inProgress) {
              return _this.compile(atom.workspace.getActiveTextEditor());
            }
          };
        })(this)
      });
    };

    LessCompilerProcess.prototype.destroy = function() {
      return this.detach();
    };

    LessCompilerProcess.prototype.compile = function(editor) {
      var fileExt, filePath, path;
      path = require('path');
      if (editor != null) {
        filePath = editor.getURI();
        fileExt = path.extname(filePath);
        if (fileExt === '.less') {
          return this.compileLess(filePath);
        }
      }
    };

    LessCompilerProcess.prototype.getParams = function(filePath, callback) {
      var firstLine, fs, params, parse, path, readline, rl;
      fs = require('fs');
      path = require('path');
      readline = require('readline');
      params = {
        file: filePath,
        compress: false,
        main: false,
        out: false
      };
      parse = (function(_this) {
        return function(firstLine) {
          firstLine.split(',').forEach(function(item) {
            var i, key, match, value;
            i = item.indexOf(':');
            if (i < 0) {
              return;
            }
            key = item.substr(0, i).trim();
            match = /^\s*\/\/\s*(.+)/.exec(key);
            if (match) {
              key = match[1];
            }
            value = item.substr(i + 1).trim();
            return params[key] = value;
          });
          if (params.main !== false) {
            return params.main.split('|').forEach(function(item) {
              return _this.getParams(path.resolve(path.dirname(filePath), item), callback);
            });
          } else {
            return callback(params);
          }
        };
      })(this);
      if (!fs.existsSync(filePath)) {
        atom.notifications.addError("Less-Compiler", {
          detail: "main: " + filePath + " not exist",
          dismissable: true
        });
        this.inProgress = false;
        return null;
      }
      rl = readline.createInterface({
        input: fs.createReadStream(filePath),
        output: process.stdout,
        terminal: false
      });
      firstLine = null;
      return rl.on('line', function(line) {
        if (firstLine === null) {
          firstLine = line;
          return parse(firstLine);
        }
      });
    };

    LessCompilerProcess.prototype.writeFile = function(contents, newFile, newPath, callback) {
      var fs, mkdirp;
      fs = require('fs');
      mkdirp = require('mkdirp');
      return mkdirp(newPath, function(error) {
        return fs.writeFile(newFile, contents, callback);
      });
    };

    LessCompilerProcess.prototype.compileLess = function(filePath) {
      var compile, fs, less, path;
      fs = require('fs');
      less = require('less');
      path = require('path');
      compile = (function(_this) {
        return function(params) {
          var parser;
          if (params.out === false) {
            return;
          }
          _this.inProgress = true;
          parser = new less.Parser({
            paths: [path.dirname(path.resolve(params.file))],
            filename: path.basename(params.file)
          });
          return fs.readFile(params.file, function(error, data) {
            return parser.parse(data.toString(), function(error, tree) {
              var css, e, newFile, newPath;
              try {
                if (error) {
                  _this.inProgress = false;
                  return atom.notifications.addError("Less-Compiler", {
                    detail: "" + error.message + " - index: " + error.index + ", line: " + error.line + ", file: " + error.filename,
                    dismissable: true
                  });
                } else {
                  css = tree.toCSS({
                    compress: params.compress
                  });
                  newFile = path.resolve(path.dirname(params.file), params.out);
                  newPath = path.dirname(newFile);
                  return _this.writeFile(css, newFile, newPath, function() {
                    _this.inProgress = false;
                    return atom.notifications.addSuccess("Less-Compiler", {
                      detail: "out: " + newFile
                    });
                  });
                }
              } catch (_error) {
                e = _error;
                _this.inProgress = false;
                return atom.notifications.addError("Less-Compiler", {
                  detail: "" + e.message + " - index: " + e.index + ", line: " + e.line + ", file: " + e.filename,
                  dismissable: true
                });
              }
            });
          });
        };
      })(this);
      return this.getParams(filePath, function(params) {
        if (params !== null) {
          return compile(params);
        }
      });
    };

    return LessCompilerProcess;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvbGVzcy1jb21waWxlci9saWIvbGVzcy1jb21waWxlci1wcm9jZXNzLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSxtQkFBQTs7QUFBQSxFQUFBLE1BQU0sQ0FBQyxPQUFQLEdBQ007cUNBQ0o7O0FBQUEsa0NBQUEsVUFBQSxHQUFZLFNBQUEsR0FBQTtBQUNWLE1BQUEsSUFBQyxDQUFBLFVBQUQsR0FBYyxLQUFkLENBQUE7YUFFQSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0IsZ0JBQWxCLEVBQW9DO0FBQUEsUUFBQSxXQUFBLEVBQWEsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFDLENBQUQsR0FBQTtBQUMvQyxZQUFBLElBQUcsQ0FBQSxLQUFFLENBQUEsVUFBTDtxQkFDRSxLQUFDLENBQUEsT0FBRCxDQUFTLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQWYsQ0FBQSxDQUFULEVBREY7YUFEK0M7VUFBQSxFQUFBO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFiO09BQXBDLEVBSFU7SUFBQSxDQUFaLENBQUE7O0FBQUEsa0NBUUEsT0FBQSxHQUFTLFNBQUEsR0FBQTthQUNQLElBQUMsQ0FBQSxNQUFELENBQUEsRUFETztJQUFBLENBUlQsQ0FBQTs7QUFBQSxrQ0FXQSxPQUFBLEdBQVMsU0FBQyxNQUFELEdBQUE7QUFDUCxVQUFBLHVCQUFBO0FBQUEsTUFBQSxJQUFBLEdBQU8sT0FBQSxDQUFRLE1BQVIsQ0FBUCxDQUFBO0FBRUEsTUFBQSxJQUFHLGNBQUg7QUFDRSxRQUFBLFFBQUEsR0FBVyxNQUFNLENBQUMsTUFBUCxDQUFBLENBQVgsQ0FBQTtBQUFBLFFBQ0EsT0FBQSxHQUFVLElBQUksQ0FBQyxPQUFMLENBQWEsUUFBYixDQURWLENBQUE7QUFHQSxRQUFBLElBQUcsT0FBQSxLQUFXLE9BQWQ7aUJBQ0UsSUFBQyxDQUFBLFdBQUQsQ0FBYSxRQUFiLEVBREY7U0FKRjtPQUhPO0lBQUEsQ0FYVCxDQUFBOztBQUFBLGtDQXFCQSxTQUFBLEdBQVcsU0FBQyxRQUFELEVBQVcsUUFBWCxHQUFBO0FBQ1QsVUFBQSxnREFBQTtBQUFBLE1BQUEsRUFBQSxHQUFLLE9BQUEsQ0FBUSxJQUFSLENBQUwsQ0FBQTtBQUFBLE1BQ0EsSUFBQSxHQUFPLE9BQUEsQ0FBUSxNQUFSLENBRFAsQ0FBQTtBQUFBLE1BRUEsUUFBQSxHQUFXLE9BQUEsQ0FBUSxVQUFSLENBRlgsQ0FBQTtBQUFBLE1BSUEsTUFBQSxHQUNFO0FBQUEsUUFBQSxJQUFBLEVBQU0sUUFBTjtBQUFBLFFBQ0EsUUFBQSxFQUFVLEtBRFY7QUFBQSxRQUVBLElBQUEsRUFBTSxLQUZOO0FBQUEsUUFHQSxHQUFBLEVBQUssS0FITDtPQUxGLENBQUE7QUFBQSxNQVVBLEtBQUEsR0FBUSxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxTQUFELEdBQUE7QUFDTixVQUFBLFNBQVMsQ0FBQyxLQUFWLENBQWdCLEdBQWhCLENBQW9CLENBQUMsT0FBckIsQ0FBNkIsU0FBQyxJQUFELEdBQUE7QUFDM0IsZ0JBQUEsb0JBQUE7QUFBQSxZQUFBLENBQUEsR0FBSSxJQUFJLENBQUMsT0FBTCxDQUFhLEdBQWIsQ0FBSixDQUFBO0FBRUEsWUFBQSxJQUFHLENBQUEsR0FBSSxDQUFQO0FBQ0Usb0JBQUEsQ0FERjthQUZBO0FBQUEsWUFLQSxHQUFBLEdBQU0sSUFBSSxDQUFDLE1BQUwsQ0FBWSxDQUFaLEVBQWUsQ0FBZixDQUFpQixDQUFDLElBQWxCLENBQUEsQ0FMTixDQUFBO0FBQUEsWUFNQSxLQUFBLEdBQVEsaUJBQWlCLENBQUMsSUFBbEIsQ0FBdUIsR0FBdkIsQ0FOUixDQUFBO0FBUUEsWUFBQSxJQUFHLEtBQUg7QUFDRSxjQUFBLEdBQUEsR0FBTSxLQUFNLENBQUEsQ0FBQSxDQUFaLENBREY7YUFSQTtBQUFBLFlBV0EsS0FBQSxHQUFRLElBQUksQ0FBQyxNQUFMLENBQVksQ0FBQSxHQUFJLENBQWhCLENBQWtCLENBQUMsSUFBbkIsQ0FBQSxDQVhSLENBQUE7bUJBYUEsTUFBTyxDQUFBLEdBQUEsQ0FBUCxHQUFjLE1BZGE7VUFBQSxDQUE3QixDQUFBLENBQUE7QUFnQkEsVUFBQSxJQUFHLE1BQU0sQ0FBQyxJQUFQLEtBQWlCLEtBQXBCO21CQUNFLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBWixDQUFrQixHQUFsQixDQUFzQixDQUFDLE9BQXZCLENBQStCLFNBQUMsSUFBRCxHQUFBO3FCQUM3QixLQUFDLENBQUEsU0FBRCxDQUFXLElBQUksQ0FBQyxPQUFMLENBQWEsSUFBSSxDQUFDLE9BQUwsQ0FBYSxRQUFiLENBQWIsRUFBcUMsSUFBckMsQ0FBWCxFQUF1RCxRQUF2RCxFQUQ2QjtZQUFBLENBQS9CLEVBREY7V0FBQSxNQUFBO21CQUlFLFFBQUEsQ0FBUyxNQUFULEVBSkY7V0FqQk07UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQVZSLENBQUE7QUFpQ0EsTUFBQSxJQUFHLENBQUEsRUFBRyxDQUFDLFVBQUgsQ0FBYyxRQUFkLENBQUo7QUFDRSxRQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsZUFBNUIsRUFDRTtBQUFBLFVBQUEsTUFBQSxFQUFTLFFBQUEsR0FBUSxRQUFSLEdBQWlCLFlBQTFCO0FBQUEsVUFDQSxXQUFBLEVBQWEsSUFEYjtTQURGLENBQUEsQ0FBQTtBQUFBLFFBSUEsSUFBQyxDQUFBLFVBQUQsR0FBYyxLQUpkLENBQUE7QUFLQSxlQUFPLElBQVAsQ0FORjtPQWpDQTtBQUFBLE1BeUNBLEVBQUEsR0FBSyxRQUFRLENBQUMsZUFBVCxDQUNIO0FBQUEsUUFBQSxLQUFBLEVBQU8sRUFBRSxDQUFDLGdCQUFILENBQW9CLFFBQXBCLENBQVA7QUFBQSxRQUNBLE1BQUEsRUFBUSxPQUFPLENBQUMsTUFEaEI7QUFBQSxRQUVBLFFBQUEsRUFBVSxLQUZWO09BREcsQ0F6Q0wsQ0FBQTtBQUFBLE1BOENBLFNBQUEsR0FBWSxJQTlDWixDQUFBO2FBZ0RBLEVBQUUsQ0FBQyxFQUFILENBQU0sTUFBTixFQUFjLFNBQUMsSUFBRCxHQUFBO0FBQ1osUUFBQSxJQUFHLFNBQUEsS0FBYSxJQUFoQjtBQUNFLFVBQUEsU0FBQSxHQUFZLElBQVosQ0FBQTtpQkFDQSxLQUFBLENBQU0sU0FBTixFQUZGO1NBRFk7TUFBQSxDQUFkLEVBakRTO0lBQUEsQ0FyQlgsQ0FBQTs7QUFBQSxrQ0EyRUEsU0FBQSxHQUFXLFNBQUMsUUFBRCxFQUFXLE9BQVgsRUFBb0IsT0FBcEIsRUFBNkIsUUFBN0IsR0FBQTtBQUNULFVBQUEsVUFBQTtBQUFBLE1BQUEsRUFBQSxHQUFLLE9BQUEsQ0FBUSxJQUFSLENBQUwsQ0FBQTtBQUFBLE1BQ0EsTUFBQSxHQUFTLE9BQUEsQ0FBUSxRQUFSLENBRFQsQ0FBQTthQUdBLE1BQUEsQ0FBTyxPQUFQLEVBQWdCLFNBQUMsS0FBRCxHQUFBO2VBQ2QsRUFBRSxDQUFDLFNBQUgsQ0FBYSxPQUFiLEVBQXNCLFFBQXRCLEVBQWdDLFFBQWhDLEVBRGM7TUFBQSxDQUFoQixFQUpTO0lBQUEsQ0EzRVgsQ0FBQTs7QUFBQSxrQ0FrRkEsV0FBQSxHQUFhLFNBQUMsUUFBRCxHQUFBO0FBQ1gsVUFBQSx1QkFBQTtBQUFBLE1BQUEsRUFBQSxHQUFLLE9BQUEsQ0FBUSxJQUFSLENBQUwsQ0FBQTtBQUFBLE1BQ0EsSUFBQSxHQUFPLE9BQUEsQ0FBUSxNQUFSLENBRFAsQ0FBQTtBQUFBLE1BRUEsSUFBQSxHQUFPLE9BQUEsQ0FBUSxNQUFSLENBRlAsQ0FBQTtBQUFBLE1BSUEsT0FBQSxHQUFVLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLE1BQUQsR0FBQTtBQUNSLGNBQUEsTUFBQTtBQUFBLFVBQUEsSUFBRyxNQUFNLENBQUMsR0FBUCxLQUFjLEtBQWpCO0FBQ0Usa0JBQUEsQ0FERjtXQUFBO0FBQUEsVUFHQSxLQUFDLENBQUEsVUFBRCxHQUFjLElBSGQsQ0FBQTtBQUFBLFVBS0EsTUFBQSxHQUFhLElBQUEsSUFBSSxDQUFDLE1BQUwsQ0FDWDtBQUFBLFlBQUEsS0FBQSxFQUFPLENBQUMsSUFBSSxDQUFDLE9BQUwsQ0FBYSxJQUFJLENBQUMsT0FBTCxDQUFhLE1BQU0sQ0FBQyxJQUFwQixDQUFiLENBQUQsQ0FBUDtBQUFBLFlBQ0EsUUFBQSxFQUFVLElBQUksQ0FBQyxRQUFMLENBQWMsTUFBTSxDQUFDLElBQXJCLENBRFY7V0FEVyxDQUxiLENBQUE7aUJBU0EsRUFBRSxDQUFDLFFBQUgsQ0FBWSxNQUFNLENBQUMsSUFBbkIsRUFBeUIsU0FBQyxLQUFELEVBQVEsSUFBUixHQUFBO21CQUN2QixNQUFNLENBQUMsS0FBUCxDQUFhLElBQUksQ0FBQyxRQUFMLENBQUEsQ0FBYixFQUE4QixTQUFDLEtBQUQsRUFBUSxJQUFSLEdBQUE7QUFDNUIsa0JBQUEsd0JBQUE7QUFBQTtBQUNFLGdCQUFBLElBQUcsS0FBSDtBQUNFLGtCQUFBLEtBQUMsQ0FBQSxVQUFELEdBQWMsS0FBZCxDQUFBO3lCQUNBLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsZUFBNUIsRUFDRTtBQUFBLG9CQUFBLE1BQUEsRUFBUSxFQUFBLEdBQUcsS0FBSyxDQUFDLE9BQVQsR0FBaUIsWUFBakIsR0FBNkIsS0FBSyxDQUFDLEtBQW5DLEdBQXlDLFVBQXpDLEdBQW1ELEtBQUssQ0FBQyxJQUF6RCxHQUE4RCxVQUE5RCxHQUF3RSxLQUFLLENBQUMsUUFBdEY7QUFBQSxvQkFDQSxXQUFBLEVBQWEsSUFEYjttQkFERixFQUZGO2lCQUFBLE1BQUE7QUFNRSxrQkFBQSxHQUFBLEdBQU0sSUFBSSxDQUFDLEtBQUwsQ0FDSjtBQUFBLG9CQUFBLFFBQUEsRUFBVSxNQUFNLENBQUMsUUFBakI7bUJBREksQ0FBTixDQUFBO0FBQUEsa0JBR0EsT0FBQSxHQUFVLElBQUksQ0FBQyxPQUFMLENBQWEsSUFBSSxDQUFDLE9BQUwsQ0FBYSxNQUFNLENBQUMsSUFBcEIsQ0FBYixFQUF3QyxNQUFNLENBQUMsR0FBL0MsQ0FIVixDQUFBO0FBQUEsa0JBSUEsT0FBQSxHQUFVLElBQUksQ0FBQyxPQUFMLENBQWEsT0FBYixDQUpWLENBQUE7eUJBTUEsS0FBQyxDQUFBLFNBQUQsQ0FBVyxHQUFYLEVBQWdCLE9BQWhCLEVBQXlCLE9BQXpCLEVBQWtDLFNBQUEsR0FBQTtBQUNoQyxvQkFBQSxLQUFDLENBQUEsVUFBRCxHQUFjLEtBQWQsQ0FBQTsyQkFDQSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQW5CLENBQThCLGVBQTlCLEVBQ0U7QUFBQSxzQkFBQSxNQUFBLEVBQVMsT0FBQSxHQUFPLE9BQWhCO3FCQURGLEVBRmdDO2tCQUFBLENBQWxDLEVBWkY7aUJBREY7ZUFBQSxjQUFBO0FBa0JFLGdCQURJLFVBQ0osQ0FBQTtBQUFBLGdCQUFBLEtBQUMsQ0FBQSxVQUFELEdBQWMsS0FBZCxDQUFBO3VCQUNBLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsZUFBNUIsRUFDRTtBQUFBLGtCQUFBLE1BQUEsRUFBUSxFQUFBLEdBQUcsQ0FBQyxDQUFDLE9BQUwsR0FBYSxZQUFiLEdBQXlCLENBQUMsQ0FBQyxLQUEzQixHQUFpQyxVQUFqQyxHQUEyQyxDQUFDLENBQUMsSUFBN0MsR0FBa0QsVUFBbEQsR0FBNEQsQ0FBQyxDQUFDLFFBQXRFO0FBQUEsa0JBQ0EsV0FBQSxFQUFhLElBRGI7aUJBREYsRUFuQkY7ZUFENEI7WUFBQSxDQUE5QixFQUR1QjtVQUFBLENBQXpCLEVBVlE7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUpWLENBQUE7YUF1Q0EsSUFBQyxDQUFBLFNBQUQsQ0FBVyxRQUFYLEVBQXFCLFNBQUMsTUFBRCxHQUFBO0FBQ25CLFFBQUEsSUFBRyxNQUFBLEtBQVksSUFBZjtpQkFDRSxPQUFBLENBQVEsTUFBUixFQURGO1NBRG1CO01BQUEsQ0FBckIsRUF4Q1c7SUFBQSxDQWxGYixDQUFBOzsrQkFBQTs7TUFGRixDQUFBO0FBQUEiCn0=

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/less-compiler/lib/less-compiler-process.coffee
