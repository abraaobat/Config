(function() {
  var lessCompilerProcess;

  lessCompilerProcess = null;

  module.exports = {
    activate: function(state) {
      var LessCompilerProcess;
      LessCompilerProcess = require('./less-compiler-process');
      lessCompilerProcess = new LessCompilerProcess();
      return lessCompilerProcess.initialize();
    },
    deactivate: function() {
      if (lessCompilerProcess != null) {
        lessCompilerProcess.destroy();
      }
      return lessCompilerProcess = null;
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvbGVzcy1jb21waWxlci9saWIvbGVzcy1jb21waWxlci5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEsbUJBQUE7O0FBQUEsRUFBQSxtQkFBQSxHQUFzQixJQUF0QixDQUFBOztBQUFBLEVBRUEsTUFBTSxDQUFDLE9BQVAsR0FDRTtBQUFBLElBQUEsUUFBQSxFQUFVLFNBQUMsS0FBRCxHQUFBO0FBQ1IsVUFBQSxtQkFBQTtBQUFBLE1BQUEsbUJBQUEsR0FBc0IsT0FBQSxDQUFRLHlCQUFSLENBQXRCLENBQUE7QUFBQSxNQUNBLG1CQUFBLEdBQTBCLElBQUEsbUJBQUEsQ0FBQSxDQUQxQixDQUFBO2FBRUEsbUJBQW1CLENBQUMsVUFBcEIsQ0FBQSxFQUhRO0lBQUEsQ0FBVjtBQUFBLElBS0EsVUFBQSxFQUFZLFNBQUEsR0FBQTs7UUFDVixtQkFBbUIsQ0FBRSxPQUFyQixDQUFBO09BQUE7YUFDQSxtQkFBQSxHQUFzQixLQUZaO0lBQUEsQ0FMWjtHQUhGLENBQUE7QUFBQSIKfQ==

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/less-compiler/lib/less-compiler.coffee
