(function() {
  var addAutoprefix, addCleanCss;

  module.exports = function(options, optionsLess) {
    optionsLess.plugins = [];
    if (options.autoprefix) {
      addAutoprefix(options.autoprefix, optionsLess);
    }
    if (options.cleancss) {
      addCleanCss(options.cleancss, optionsLess);
    }
    return optionsLess;
  };

  addAutoprefix = function(options, optionsLess) {
    var AutoprefixLessPlugin, autoprefixOptions;
    AutoprefixLessPlugin = require('less-plugin-autoprefix');
    autoprefixOptions = options;
    if (typeof options === 'string') {
      autoprefixOptions = {
        browsers: options.split(';')
      };
    }
    return optionsLess.plugins.push(new AutoprefixLessPlugin(autoprefixOptions));
  };

  addCleanCss = function(options, optionsLess) {
    var CleanCssLessPlugin, cleancssOptions;
    CleanCssLessPlugin = require('less-plugin-clean-css');
    cleancssOptions = options;
    if (typeof options === 'string') {
      cleancssOptions = {
        compatibility: options
      };
    }
    return optionsLess.plugins.push(new CleanCssLessPlugin(cleancssOptions));
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvYXRvbS1sZXNzL2xpYi9sZXNzLXBsdWdpbnMuY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQUE7QUFBQSxNQUFBLDBCQUFBOztBQUFBLEVBQUEsTUFBTSxDQUFDLE9BQVAsR0FDSSxTQUFDLE9BQUQsRUFBVSxXQUFWLEdBQUE7QUFDSSxJQUFBLFdBQVcsQ0FBQyxPQUFaLEdBQXNCLEVBQXRCLENBQUE7QUFFQSxJQUFBLElBQUcsT0FBTyxDQUFDLFVBQVg7QUFDSSxNQUFBLGFBQUEsQ0FBYyxPQUFPLENBQUMsVUFBdEIsRUFBa0MsV0FBbEMsQ0FBQSxDQURKO0tBRkE7QUFJQSxJQUFBLElBQUcsT0FBTyxDQUFDLFFBQVg7QUFDSSxNQUFBLFdBQUEsQ0FBWSxPQUFPLENBQUMsUUFBcEIsRUFBOEIsV0FBOUIsQ0FBQSxDQURKO0tBSkE7V0FPQSxZQVJKO0VBQUEsQ0FESixDQUFBOztBQUFBLEVBV0EsYUFBQSxHQUFnQixTQUFDLE9BQUQsRUFBVSxXQUFWLEdBQUE7QUFDWixRQUFBLHVDQUFBO0FBQUEsSUFBQSxvQkFBQSxHQUF1QixPQUFBLENBQVEsd0JBQVIsQ0FBdkIsQ0FBQTtBQUFBLElBRUEsaUJBQUEsR0FBb0IsT0FGcEIsQ0FBQTtBQUdBLElBQUEsSUFBRyxNQUFBLENBQUEsT0FBQSxLQUFrQixRQUFyQjtBQUNJLE1BQUEsaUJBQUEsR0FDSTtBQUFBLFFBQUEsUUFBQSxFQUFVLE9BQU8sQ0FBQyxLQUFSLENBQWMsR0FBZCxDQUFWO09BREosQ0FESjtLQUhBO1dBT0EsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFwQixDQUE2QixJQUFBLG9CQUFBLENBQXFCLGlCQUFyQixDQUE3QixFQVJZO0VBQUEsQ0FYaEIsQ0FBQTs7QUFBQSxFQXFCQSxXQUFBLEdBQWMsU0FBQyxPQUFELEVBQVUsV0FBVixHQUFBO0FBQ1YsUUFBQSxtQ0FBQTtBQUFBLElBQUEsa0JBQUEsR0FBcUIsT0FBQSxDQUFRLHVCQUFSLENBQXJCLENBQUE7QUFBQSxJQUVBLGVBQUEsR0FBa0IsT0FGbEIsQ0FBQTtBQUdBLElBQUEsSUFBRyxNQUFBLENBQUEsT0FBQSxLQUFrQixRQUFyQjtBQUNJLE1BQUEsZUFBQSxHQUNJO0FBQUEsUUFBQSxhQUFBLEVBQWUsT0FBZjtPQURKLENBREo7S0FIQTtXQU9BLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBcEIsQ0FBNkIsSUFBQSxrQkFBQSxDQUFtQixlQUFuQixDQUE3QixFQVJVO0VBQUEsQ0FyQmQsQ0FBQTtBQUFBIgp9

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/atom-less/lib/less-plugins.coffee
