(function() {
  module.exports = {
    config: {
      iconsPlus: {
        type: 'boolean',
        "default": false,
        description: 'Use additional and enhanced icons.'
      },
      noColor: {
        type: 'boolean',
        "default": false,
        description: 'Display icons without color.'
      }
    },
    activate: function(state) {
      atom.config.onDidChange('seti-icons.iconsPlus', (function(_this) {
        return function(_arg) {
          var newValue;
          newValue = _arg.newValue;
          return _this.iconsPlus(newValue);
        };
      })(this));
      atom.config.onDidChange('seti-icons.noColor', (function(_this) {
        return function(_arg) {
          var newValue;
          newValue = _arg.newValue;
          return _this.noColor(newValue);
        };
      })(this));
      this.iconsPlus(atom.config.get('seti-icons.iconsPlus'));
      return this.noColor(atom.config.get('seti-icons.noColor'));
    },
    update: function(enable, text) {
      var body;
      body = document.querySelector('body');
      if (enable) {
        return body.className = "" + body.className + " " + text;
      } else {
        return body.className = body.className.replace(" " + text, '');
      }
    },
    iconsPlus: function(enable) {
      return this.update(enable, 'seti-icons-plus');
    },
    noColor: function(enable) {
      return this.update(enable, 'seti-icons-no-color');
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvc2V0aS1pY29ucy9pbmRleC5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLEVBQUEsTUFBTSxDQUFDLE9BQVAsR0FDRTtBQUFBLElBQUEsTUFBQSxFQUNFO0FBQUEsTUFBQSxTQUFBLEVBQ0U7QUFBQSxRQUFBLElBQUEsRUFBTSxTQUFOO0FBQUEsUUFDQSxTQUFBLEVBQVMsS0FEVDtBQUFBLFFBRUEsV0FBQSxFQUFhLG9DQUZiO09BREY7QUFBQSxNQUlBLE9BQUEsRUFDRTtBQUFBLFFBQUEsSUFBQSxFQUFNLFNBQU47QUFBQSxRQUNBLFNBQUEsRUFBUyxLQURUO0FBQUEsUUFFQSxXQUFBLEVBQWEsOEJBRmI7T0FMRjtLQURGO0FBQUEsSUFVQSxRQUFBLEVBQVUsU0FBRSxLQUFGLEdBQUE7QUFDUixNQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBWixDQUF3QixzQkFBeEIsRUFBZ0QsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsSUFBRCxHQUFBO0FBQzlDLGNBQUEsUUFBQTtBQUFBLFVBRGlELFdBQUYsS0FBRSxRQUNqRCxDQUFBO2lCQUFBLEtBQUMsQ0FBQSxTQUFELENBQVcsUUFBWCxFQUQ4QztRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWhELENBQUEsQ0FBQTtBQUFBLE1BR0EsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFaLENBQXdCLG9CQUF4QixFQUE4QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxJQUFELEdBQUE7QUFDNUMsY0FBQSxRQUFBO0FBQUEsVUFEK0MsV0FBRixLQUFFLFFBQy9DLENBQUE7aUJBQUEsS0FBQyxDQUFBLE9BQUQsQ0FBUyxRQUFULEVBRDRDO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBOUMsQ0FIQSxDQUFBO0FBQUEsTUFNQSxJQUFDLENBQUEsU0FBRCxDQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQixzQkFBaEIsQ0FBWCxDQU5BLENBQUE7YUFPQSxJQUFDLENBQUEsT0FBRCxDQUFTLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQixvQkFBaEIsQ0FBVCxFQVJRO0lBQUEsQ0FWVjtBQUFBLElBb0JBLE1BQUEsRUFBUSxTQUFFLE1BQUYsRUFBVSxJQUFWLEdBQUE7QUFDTixVQUFBLElBQUE7QUFBQSxNQUFBLElBQUEsR0FBTyxRQUFRLENBQUMsYUFBVCxDQUF1QixNQUF2QixDQUFQLENBQUE7QUFFQSxNQUFBLElBQUcsTUFBSDtlQUNFLElBQUksQ0FBQyxTQUFMLEdBQWlCLEVBQUEsR0FBRyxJQUFJLENBQUMsU0FBUixHQUFrQixHQUFsQixHQUFxQixLQUR4QztPQUFBLE1BQUE7ZUFHRSxJQUFJLENBQUMsU0FBTCxHQUFpQixJQUFJLENBQUMsU0FBUyxDQUFDLE9BQWYsQ0FBd0IsR0FBQSxHQUFHLElBQTNCLEVBQW1DLEVBQW5DLEVBSG5CO09BSE07SUFBQSxDQXBCUjtBQUFBLElBNEJBLFNBQUEsRUFBVyxTQUFFLE1BQUYsR0FBQTthQUNULElBQUMsQ0FBQSxNQUFELENBQVEsTUFBUixFQUFnQixpQkFBaEIsRUFEUztJQUFBLENBNUJYO0FBQUEsSUErQkEsT0FBQSxFQUFTLFNBQUUsTUFBRixHQUFBO2FBQ1AsSUFBQyxDQUFBLE1BQUQsQ0FBUSxNQUFSLEVBQWdCLHFCQUFoQixFQURPO0lBQUEsQ0EvQlQ7R0FERixDQUFBO0FBQUEiCn0=

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/seti-icons/index.coffee
