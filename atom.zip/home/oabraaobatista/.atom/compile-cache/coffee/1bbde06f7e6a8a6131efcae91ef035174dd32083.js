(function() {
  var CompositeDisposable, LessBuild, fs, less, path;

  fs = require("fs");

  less = require("less");

  path = require("path");

  CompositeDisposable = require('atom').CompositeDisposable;

  module.exports = LessBuild = {
    lastActiveDisposable: null,
    subscriptions: null,
    activate: function(state) {
      this.subscriptions = new CompositeDisposable;
      this.subscriptions.add(atom.commands.add('atom-workspace', {
        'less-build:build': (function(_this) {
          return function() {
            return _this.build();
          };
        })(this)
      }));
      this.onActivePanelChanged();
      return atom.workspace.onDidChangeActivePaneItem((function(_this) {
        return function(activePaneItem) {
          if (typeof lastActiveDisposable !== "undefined" && lastActiveDisposable !== null) {
            _this.lastActiveDisposable.dispose();
          }
          return _this.onActivePanelChanged();
        };
      })(this));
    },
    deactivate: function() {
      if (typeof lastActiveDisposable !== "undefined" && lastActiveDisposable !== null) {
        this.lastActiveDisposable.dispose();
      }
      return this.subscriptions.dispose();
    },
    onActivePanelChanged: function() {
      var editor;
      editor = atom.workspace.getActiveTextEditor();
      if (editor == null) {
        return;
      }
      return this.lastActiveDisposable = editor.onDidSave((function(_this) {
        return function() {
          return _this.build();
        };
      })(this));
    },
    build: function() {
      var editor, fileExtension;
      editor = atom.workspace.getActiveTextEditor();
      fileExtension = editor.getTitle().split(".")[1];
      if (fileExtension === 'less') {
        return this.buildLESS();
      }
    },
    buildLESS: function() {
      var buildOptions, dest, destPath, projectName, projectPath, src, srcPath, _results;
      projectName = atom.config.get('less-build.project');
      projectPath = atom.project.getPaths()[0];
      if (projectPath == null) {
        projectPath = "";
      }
      if (projectPath.slice(-projectName.length) !== projectName) {
        return;
      }
      buildOptions = atom.config.get('less-build.options');
      if (buildOptions == null) {
        return;
      }
      _results = [];
      for (src in buildOptions) {
        dest = buildOptions[src];
        srcPath = path.resolve(projectPath, src);
        destPath = path.resolve(projectPath, dest);
        _results.push(this.renderLESS(srcPath, destPath));
      }
      return _results;
    },
    renderLESS: function(src, dest) {
      var lessOptions, text;
      text = fs.readFileSync(src, {
        encoding: 'utf8'
      });
      lessOptions = {
        paths: [path.dirname(path.resolve(src))],
        filename: path.basename(src)
      };
      return less.render(text, lessOptions, (function(_this) {
        return function(error, output) {
          var css;
          if (error !== null) {
            return _this.reportError(error);
          }
          css = output.css;
          return fs.writeFile(dest, css, {}, function(error) {
            if (error !== null) {
              return atom.notifications.addError('Unable to write to output file');
            } else {
              return atom.notifications.addSuccess('less-build: success');
            }
          });
        };
      })(this));
    },
    reportError: function(error) {
      var errorMessage;
      errorMessage = "" + error.filename + " [" + error.line + ", " + error.column + "]: " + error.message;
      return atom.notifications.addError(errorMessage, {});
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvbGVzcy1idWlsZC9saWIvbGVzcy1idWlsZC5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEsOENBQUE7O0FBQUEsRUFBQSxFQUFBLEdBQUssT0FBQSxDQUFRLElBQVIsQ0FBTCxDQUFBOztBQUFBLEVBQ0EsSUFBQSxHQUFPLE9BQUEsQ0FBUSxNQUFSLENBRFAsQ0FBQTs7QUFBQSxFQUVBLElBQUEsR0FBTyxPQUFBLENBQVEsTUFBUixDQUZQLENBQUE7O0FBQUEsRUFHQyxzQkFBdUIsT0FBQSxDQUFRLE1BQVIsRUFBdkIsbUJBSEQsQ0FBQTs7QUFBQSxFQUtBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLFNBQUEsR0FDZjtBQUFBLElBQUEsb0JBQUEsRUFBc0IsSUFBdEI7QUFBQSxJQUNBLGFBQUEsRUFBZSxJQURmO0FBQUEsSUFHQSxRQUFBLEVBQVUsU0FBQyxLQUFELEdBQUE7QUFDUixNQUFBLElBQUMsQ0FBQSxhQUFELEdBQWlCLEdBQUEsQ0FBQSxtQkFBakIsQ0FBQTtBQUFBLE1BQ0EsSUFBQyxDQUFBLGFBQWEsQ0FBQyxHQUFmLENBQW1CLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFBb0M7QUFBQSxRQUFBLGtCQUFBLEVBQW9CLENBQUEsU0FBQSxLQUFBLEdBQUE7aUJBQUEsU0FBQSxHQUFBO21CQUFHLEtBQUMsQ0FBQSxLQUFELENBQUEsRUFBSDtVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXBCO09BQXBDLENBQW5CLENBREEsQ0FBQTtBQUFBLE1BR0EsSUFBQyxDQUFBLG9CQUFELENBQUEsQ0FIQSxDQUFBO2FBSUEsSUFBSSxDQUFDLFNBQVMsQ0FBQyx5QkFBZixDQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxjQUFELEdBQUE7QUFDdkMsVUFBQSxJQUFtQyw0RUFBbkM7QUFBQSxZQUFBLEtBQUMsQ0FBQSxvQkFBb0IsQ0FBQyxPQUF0QixDQUFBLENBQUEsQ0FBQTtXQUFBO2lCQUNBLEtBQUMsQ0FBQSxvQkFBRCxDQUFBLEVBRnVDO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekMsRUFMUTtJQUFBLENBSFY7QUFBQSxJQVlBLFVBQUEsRUFBWSxTQUFBLEdBQUE7QUFDVixNQUFBLElBQW1DLDRFQUFuQztBQUFBLFFBQUEsSUFBQyxDQUFBLG9CQUFvQixDQUFDLE9BQXRCLENBQUEsQ0FBQSxDQUFBO09BQUE7YUFDQSxJQUFDLENBQUEsYUFBYSxDQUFDLE9BQWYsQ0FBQSxFQUZVO0lBQUEsQ0FaWjtBQUFBLElBZ0JBLG9CQUFBLEVBQXNCLFNBQUEsR0FBQTtBQUNwQixVQUFBLE1BQUE7QUFBQSxNQUFBLE1BQUEsR0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFmLENBQUEsQ0FBVCxDQUFBO0FBQ0EsTUFBQSxJQUFjLGNBQWQ7QUFBQSxjQUFBLENBQUE7T0FEQTthQUdBLElBQUMsQ0FBQSxvQkFBRCxHQUF3QixNQUFNLENBQUMsU0FBUCxDQUFpQixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO2lCQUN2QyxLQUFDLENBQUEsS0FBRCxDQUFBLEVBRHVDO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBakIsRUFKSjtJQUFBLENBaEJ0QjtBQUFBLElBdUJBLEtBQUEsRUFBTyxTQUFBLEdBQUE7QUFDTCxVQUFBLHFCQUFBO0FBQUEsTUFBQSxNQUFBLEdBQVMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBZixDQUFBLENBQVQsQ0FBQTtBQUFBLE1BQ0EsYUFBQSxHQUFnQixNQUFNLENBQUMsUUFBUCxDQUFBLENBQWlCLENBQUMsS0FBbEIsQ0FBd0IsR0FBeEIsQ0FBNkIsQ0FBQSxDQUFBLENBRDdDLENBQUE7QUFFQSxNQUFBLElBQUcsYUFBQSxLQUFpQixNQUFwQjtlQUNFLElBQUMsQ0FBQSxTQUFELENBQUEsRUFERjtPQUhLO0lBQUEsQ0F2QlA7QUFBQSxJQTZCQSxTQUFBLEVBQVcsU0FBQSxHQUFBO0FBQ1QsVUFBQSw4RUFBQTtBQUFBLE1BQUEsV0FBQSxHQUFjLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQixvQkFBaEIsQ0FBZCxDQUFBO0FBQUEsTUFDQSxXQUFBLEdBQWMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFiLENBQUEsQ0FBd0IsQ0FBQSxDQUFBLENBRHRDLENBQUE7QUFFQSxNQUFBLElBQU8sbUJBQVA7QUFDRSxRQUFBLFdBQUEsR0FBYyxFQUFkLENBREY7T0FGQTtBQUtBLE1BQUEsSUFBVSxXQUFXLENBQUMsS0FBWixDQUFrQixDQUFBLFdBQVksQ0FBQyxNQUEvQixDQUFBLEtBQTRDLFdBQXREO0FBQUEsY0FBQSxDQUFBO09BTEE7QUFBQSxNQU9BLFlBQUEsR0FBZSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0Isb0JBQWhCLENBUGYsQ0FBQTtBQVFBLE1BQUEsSUFBYyxvQkFBZDtBQUFBLGNBQUEsQ0FBQTtPQVJBO0FBVUE7V0FBQSxtQkFBQTtpQ0FBQTtBQUNFLFFBQUEsT0FBQSxHQUFVLElBQUksQ0FBQyxPQUFMLENBQWEsV0FBYixFQUEwQixHQUExQixDQUFWLENBQUE7QUFBQSxRQUNBLFFBQUEsR0FBVyxJQUFJLENBQUMsT0FBTCxDQUFhLFdBQWIsRUFBMEIsSUFBMUIsQ0FEWCxDQUFBO0FBQUEsc0JBRUEsSUFBQyxDQUFBLFVBQUQsQ0FBWSxPQUFaLEVBQXFCLFFBQXJCLEVBRkEsQ0FERjtBQUFBO3NCQVhTO0lBQUEsQ0E3Qlg7QUFBQSxJQTZDQSxVQUFBLEVBQVksU0FBQyxHQUFELEVBQU0sSUFBTixHQUFBO0FBQ1YsVUFBQSxpQkFBQTtBQUFBLE1BQUEsSUFBQSxHQUFPLEVBQUUsQ0FBQyxZQUFILENBQWdCLEdBQWhCLEVBQXFCO0FBQUEsUUFBQyxRQUFBLEVBQVUsTUFBWDtPQUFyQixDQUFQLENBQUE7QUFBQSxNQUNBLFdBQUEsR0FDRTtBQUFBLFFBQUEsS0FBQSxFQUFPLENBQUMsSUFBSSxDQUFDLE9BQUwsQ0FBYSxJQUFJLENBQUMsT0FBTCxDQUFhLEdBQWIsQ0FBYixDQUFELENBQVA7QUFBQSxRQUNBLFFBQUEsRUFBVSxJQUFJLENBQUMsUUFBTCxDQUFjLEdBQWQsQ0FEVjtPQUZGLENBQUE7YUFLQSxJQUFJLENBQUMsTUFBTCxDQUFZLElBQVosRUFBa0IsV0FBbEIsRUFBK0IsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsS0FBRCxFQUFRLE1BQVIsR0FBQTtBQUM3QixjQUFBLEdBQUE7QUFBQSxVQUFBLElBQUcsS0FBQSxLQUFXLElBQWQ7QUFDRSxtQkFBTyxLQUFDLENBQUEsV0FBRCxDQUFhLEtBQWIsQ0FBUCxDQURGO1dBQUE7QUFBQSxVQUdBLEdBQUEsR0FBTSxNQUFNLENBQUMsR0FIYixDQUFBO2lCQUlBLEVBQUUsQ0FBQyxTQUFILENBQWEsSUFBYixFQUFtQixHQUFuQixFQUF3QixFQUF4QixFQUE0QixTQUFDLEtBQUQsR0FBQTtBQUMxQixZQUFBLElBQUcsS0FBQSxLQUFXLElBQWQ7cUJBQ0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0QixnQ0FBNUIsRUFERjthQUFBLE1BQUE7cUJBR0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFuQixDQUE4QixxQkFBOUIsRUFIRjthQUQwQjtVQUFBLENBQTVCLEVBTDZCO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBL0IsRUFOVTtJQUFBLENBN0NaO0FBQUEsSUE4REEsV0FBQSxFQUFhLFNBQUMsS0FBRCxHQUFBO0FBQ1gsVUFBQSxZQUFBO0FBQUEsTUFBQSxZQUFBLEdBQWUsRUFBQSxHQUFHLEtBQUssQ0FBQyxRQUFULEdBQWtCLElBQWxCLEdBQXNCLEtBQUssQ0FBQyxJQUE1QixHQUFpQyxJQUFqQyxHQUFxQyxLQUFLLENBQUMsTUFBM0MsR0FBa0QsS0FBbEQsR0FBdUQsS0FBSyxDQUFDLE9BQTVFLENBQUE7YUFDQSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLFlBQTVCLEVBQTBDLEVBQTFDLEVBRlc7SUFBQSxDQTlEYjtHQU5GLENBQUE7QUFBQSIKfQ==

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/less-build/lib/less-build.coffee
