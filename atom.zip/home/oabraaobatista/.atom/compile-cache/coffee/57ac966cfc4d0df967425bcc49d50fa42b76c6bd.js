(function() {
  var CompositeDisposable, LessAutocompile, LessAutocompileView;

  LessAutocompileView = require('./less-autocompile-view');

  CompositeDisposable = require('atom').CompositeDisposable;

  module.exports = LessAutocompile = {
    lessAutocompileView: null,
    activate: function(state) {
      return this.lessAutocompileView = new LessAutocompileView(state.lessAutocompileViewState);
    },
    deactivate: function() {
      return this.lessAutocompileView.destroy();
    },
    serialize: function() {
      return {
        lessAutocompileViewState: this.lessAutocompileView.serialize()
      };
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvbGVzcy1hdXRvY29tcGlsZS9saWIvbGVzcy1hdXRvY29tcGlsZS5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEseURBQUE7O0FBQUEsRUFBQSxtQkFBQSxHQUF3QixPQUFBLENBQVEseUJBQVIsQ0FBeEIsQ0FBQTs7QUFBQSxFQUNDLHNCQUF1QixPQUFBLENBQVEsTUFBUixFQUF2QixtQkFERCxDQUFBOztBQUFBLEVBR0EsTUFBTSxDQUFDLE9BQVAsR0FBaUIsZUFBQSxHQUNmO0FBQUEsSUFBQSxtQkFBQSxFQUFxQixJQUFyQjtBQUFBLElBRUEsUUFBQSxFQUFVLFNBQUMsS0FBRCxHQUFBO2FBQ1IsSUFBQyxDQUFBLG1CQUFELEdBQTJCLElBQUEsbUJBQUEsQ0FBb0IsS0FBSyxDQUFDLHdCQUExQixFQURuQjtJQUFBLENBRlY7QUFBQSxJQUtBLFVBQUEsRUFBWSxTQUFBLEdBQUE7YUFDVixJQUFDLENBQUEsbUJBQW1CLENBQUMsT0FBckIsQ0FBQSxFQURVO0lBQUEsQ0FMWjtBQUFBLElBUUEsU0FBQSxFQUFXLFNBQUEsR0FBQTthQUNUO0FBQUEsUUFBQSx3QkFBQSxFQUEwQixJQUFDLENBQUEsbUJBQW1CLENBQUMsU0FBckIsQ0FBQSxDQUExQjtRQURTO0lBQUEsQ0FSWDtHQUpGLENBQUE7QUFBQSIKfQ==

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/less-autocompile/lib/less-autocompile.coffee
