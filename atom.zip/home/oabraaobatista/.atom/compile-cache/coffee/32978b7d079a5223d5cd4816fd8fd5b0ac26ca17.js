(function() {
  var LessAutocompileView, async, fs, less, mkdirp, path, readline;

  async = require('async');

  fs = require('fs');

  less = require('less');

  mkdirp = require('mkdirp');

  path = require('path');

  readline = require('readline');

  module.exports = LessAutocompileView = (function() {
    function LessAutocompileView(serializeState) {
      atom.commands.add('atom-workspace', {
        'core:save': (function(_this) {
          return function() {
            return _this.handleSave();
          };
        })(this)
      });
    }

    LessAutocompileView.prototype.serialize = function() {};

    LessAutocompileView.prototype.destroy = function() {};

    LessAutocompileView.prototype.handleSave = function() {
      this.activeEditor = atom.workspace.getActiveTextEditor();
      if (this.activeEditor) {
        this.filePath = this.activeEditor.getURI();
        this.fileExt = path.extname(this.filePath);
        if (this.fileExt === '.less') {
          return this.getParams(this.filePath, (function(_this) {
            return function(params) {
              return _this.compileLess(params);
            };
          })(this));
        }
      }
    };

    LessAutocompileView.prototype.writeFiles = function(output, newPath, newFile) {
      return async.series({
        css: (function(_this) {
          return function(callback) {
            if (output.css) {
              return _this.writeFile(output.css, newPath, newFile, function() {
                return callback(null, newFile);
              });
            } else {
              return callback(null, null);
            }
          };
        })(this),
        map: (function(_this) {
          return function(callback) {
            if (output.map) {
              newFile = "" + newFile + ".map";
              return _this.writeFile(output.map, newPath, newFile, function() {
                return callback(null, newFile);
              });
            } else {
              return callback(null, null);
            }
          };
        })(this)
      }, function(err, results) {
        if (err) {
          return atom.notifications.addError(err, {
            dismissable: true
          });
        } else {
          if (results.map !== null) {
            return atom.notifications.addSuccess("Files created", {
              detail: "" + results.css + "\n" + results.map
            });
          } else {
            return atom.notifications.addSuccess("File created", {
              detail: results.css
            });
          }
        }
      });
    };

    LessAutocompileView.prototype.writeFile = function(contentFile, newPath, newFile, callback) {
      return mkdirp(newPath, function(err) {
        if (err) {
          return atom.notifications.addError(err, {
            dismissable: true
          });
        } else {
          return fs.writeFile(newFile, contentFile, callback);
        }
      });
    };

    LessAutocompileView.prototype.compileLess = function(params) {
      var contentFile, firstLine, optionsLess, rl;
      if (!params.out) {
        return;
      }
      firstLine = true;
      contentFile = [];
      optionsLess = {
        paths: [path.dirname(path.resolve(params.file))],
        filename: path.basename(params.file),
        compress: params.compress === 'true' ? true : false,
        sourceMap: params.sourcemap === 'true' ? {} : false
      };
      rl = readline.createInterface({
        input: fs.createReadStream(params.file),
        terminal: false
      });
      rl.on('line', function(line) {
        if (!firstLine) {
          contentFile.push(line);
        }
        return firstLine = false;
      });
      return rl.on('close', (function(_this) {
        return function() {
          return _this.renderLess(params, contentFile, optionsLess);
        };
      })(this));
    };

    LessAutocompileView.prototype.renderLess = function(params, contentFile, optionsLess) {
      contentFile = contentFile.join("\n");
      return less.render(contentFile, optionsLess).then((function(_this) {
        return function(output) {
          var newFile, newPath;
          newFile = path.resolve(path.dirname(params.file), params.out);
          newPath = path.dirname(newFile);
          return _this.writeFiles(output, newPath, newFile);
        };
      })(this), function(err) {
        if (err) {
          return atom.notifications.addError(err.message, {
            detail: "" + err.filename + ":" + err.line,
            dismissable: true
          });
        }
      });
    };

    LessAutocompileView.prototype.getParams = function(filePath, callback) {
      var rl;
      if (!fs.existsSync(filePath)) {
        atom.notifications.addError("" + filePath + " not exist", {
          dismissable: true
        });
        return;
      }
      this.params = {
        file: filePath
      };
      this.firstLine = true;
      rl = readline.createInterface({
        input: fs.createReadStream(filePath),
        terminal: false
      });
      rl.on('line', (function(_this) {
        return function(line) {
          return _this.parseFirstLine(line);
        };
      })(this));
      return rl.on('close', (function(_this) {
        return function() {
          if (_this.params.main) {
            return _this.getParams(path.resolve(path.dirname(filePath), _this.params.main), callback);
          } else {
            return callback(_this.params);
          }
        };
      })(this));
    };

    LessAutocompileView.prototype.parseFirstLine = function(line) {
      if (!this.firstLine) {
        return;
      }
      this.firstLine = false;
      return line.split(',').forEach((function(_this) {
        return function(item) {
          var i, key, match, value;
          i = item.indexOf(':');
          if (i < 0) {
            return;
          }
          key = item.substr(0, i).trim();
          match = /^\s*\/\/\s*(.+)/.exec(key);
          if (match) {
            key = match[1];
          }
          value = item.substr(i + 1).trim();
          return _this.params[key] = value;
        };
      })(this));
    };

    return LessAutocompileView;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BYnJhw6NvIEJhdGlzdGEvLmF0b20vcGFja2FnZXMvbGVzcy1hdXRvY29tcGlsZS9saWIvbGVzcy1hdXRvY29tcGlsZS12aWV3LmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSw0REFBQTs7QUFBQSxFQUFBLEtBQUEsR0FBVyxPQUFBLENBQVEsT0FBUixDQUFYLENBQUE7O0FBQUEsRUFDQSxFQUFBLEdBQVcsT0FBQSxDQUFRLElBQVIsQ0FEWCxDQUFBOztBQUFBLEVBRUEsSUFBQSxHQUFXLE9BQUEsQ0FBUSxNQUFSLENBRlgsQ0FBQTs7QUFBQSxFQUdBLE1BQUEsR0FBVyxPQUFBLENBQVEsUUFBUixDQUhYLENBQUE7O0FBQUEsRUFJQSxJQUFBLEdBQVcsT0FBQSxDQUFRLE1BQVIsQ0FKWCxDQUFBOztBQUFBLEVBS0EsUUFBQSxHQUFXLE9BQUEsQ0FBUSxVQUFSLENBTFgsQ0FBQTs7QUFBQSxFQU9BLE1BQU0sQ0FBQyxPQUFQLEdBQ007QUFDUyxJQUFBLDZCQUFDLGNBQUQsR0FBQTtBQUNYLE1BQUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFkLENBQWtCLGdCQUFsQixFQUFvQztBQUFBLFFBQUEsV0FBQSxFQUFhLENBQUEsU0FBQSxLQUFBLEdBQUE7aUJBQUEsU0FBQSxHQUFBO21CQUFHLEtBQUMsQ0FBQSxVQUFELENBQUEsRUFBSDtVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWI7T0FBcEMsQ0FBQSxDQURXO0lBQUEsQ0FBYjs7QUFBQSxrQ0FHQSxTQUFBLEdBQVcsU0FBQSxHQUFBLENBSFgsQ0FBQTs7QUFBQSxrQ0FLQSxPQUFBLEdBQVMsU0FBQSxHQUFBLENBTFQsQ0FBQTs7QUFBQSxrQ0FPQSxVQUFBLEdBQVksU0FBQSxHQUFBO0FBQ1YsTUFBQSxJQUFDLENBQUEsWUFBRCxHQUFnQixJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFmLENBQUEsQ0FBaEIsQ0FBQTtBQUVBLE1BQUEsSUFBRyxJQUFDLENBQUEsWUFBSjtBQUNFLFFBQUEsSUFBQyxDQUFBLFFBQUQsR0FBWSxJQUFDLENBQUEsWUFBWSxDQUFDLE1BQWQsQ0FBQSxDQUFaLENBQUE7QUFBQSxRQUNBLElBQUMsQ0FBQSxPQUFELEdBQVcsSUFBSSxDQUFDLE9BQUwsQ0FBYSxJQUFDLENBQUEsUUFBZCxDQURYLENBQUE7QUFHQSxRQUFBLElBQUcsSUFBQyxDQUFBLE9BQUQsS0FBWSxPQUFmO2lCQUNFLElBQUMsQ0FBQSxTQUFELENBQVcsSUFBQyxDQUFBLFFBQVosRUFBc0IsQ0FBQSxTQUFBLEtBQUEsR0FBQTttQkFBQSxTQUFDLE1BQUQsR0FBQTtxQkFDcEIsS0FBQyxDQUFBLFdBQUQsQ0FBYSxNQUFiLEVBRG9CO1lBQUEsRUFBQTtVQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBdEIsRUFERjtTQUpGO09BSFU7SUFBQSxDQVBaLENBQUE7O0FBQUEsa0NBa0JBLFVBQUEsR0FBWSxTQUFDLE1BQUQsRUFBUyxPQUFULEVBQWtCLE9BQWxCLEdBQUE7YUFDVixLQUFLLENBQUMsTUFBTixDQUNFO0FBQUEsUUFBQSxHQUFBLEVBQUssQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFDLFFBQUQsR0FBQTtBQUNILFlBQUEsSUFBRyxNQUFNLENBQUMsR0FBVjtxQkFDRSxLQUFDLENBQUEsU0FBRCxDQUFXLE1BQU0sQ0FBQyxHQUFsQixFQUF1QixPQUF2QixFQUFnQyxPQUFoQyxFQUF5QyxTQUFBLEdBQUE7dUJBQ3ZDLFFBQUEsQ0FBUyxJQUFULEVBQWUsT0FBZixFQUR1QztjQUFBLENBQXpDLEVBREY7YUFBQSxNQUFBO3FCQUlFLFFBQUEsQ0FBUyxJQUFULEVBQWUsSUFBZixFQUpGO2FBREc7VUFBQSxFQUFBO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFMO0FBQUEsUUFNQSxHQUFBLEVBQUssQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFDLFFBQUQsR0FBQTtBQUNILFlBQUEsSUFBRyxNQUFNLENBQUMsR0FBVjtBQUNFLGNBQUEsT0FBQSxHQUFVLEVBQUEsR0FBRyxPQUFILEdBQVcsTUFBckIsQ0FBQTtxQkFFQSxLQUFDLENBQUEsU0FBRCxDQUFXLE1BQU0sQ0FBQyxHQUFsQixFQUF1QixPQUF2QixFQUFnQyxPQUFoQyxFQUF5QyxTQUFBLEdBQUE7dUJBQ3ZDLFFBQUEsQ0FBUyxJQUFULEVBQWUsT0FBZixFQUR1QztjQUFBLENBQXpDLEVBSEY7YUFBQSxNQUFBO3FCQU1FLFFBQUEsQ0FBUyxJQUFULEVBQWUsSUFBZixFQU5GO2FBREc7VUFBQSxFQUFBO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQU5MO09BREYsRUFlRSxTQUFDLEdBQUQsRUFBTSxPQUFOLEdBQUE7QUFDQSxRQUFBLElBQUcsR0FBSDtpQkFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLEdBQTVCLEVBQ0U7QUFBQSxZQUFBLFdBQUEsRUFBYSxJQUFiO1dBREYsRUFERjtTQUFBLE1BQUE7QUFJRSxVQUFBLElBQUcsT0FBTyxDQUFDLEdBQVIsS0FBZSxJQUFsQjttQkFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQW5CLENBQThCLGVBQTlCLEVBQ0U7QUFBQSxjQUFBLE1BQUEsRUFBUSxFQUFBLEdBQUcsT0FBTyxDQUFDLEdBQVgsR0FBZSxJQUFmLEdBQW1CLE9BQU8sQ0FBQyxHQUFuQzthQURGLEVBREY7V0FBQSxNQUFBO21CQUlFLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBbkIsQ0FBOEIsY0FBOUIsRUFDRTtBQUFBLGNBQUEsTUFBQSxFQUFRLE9BQU8sQ0FBQyxHQUFoQjthQURGLEVBSkY7V0FKRjtTQURBO01BQUEsQ0FmRixFQURVO0lBQUEsQ0FsQlosQ0FBQTs7QUFBQSxrQ0E4Q0EsU0FBQSxHQUFXLFNBQUMsV0FBRCxFQUFjLE9BQWQsRUFBdUIsT0FBdkIsRUFBZ0MsUUFBaEMsR0FBQTthQUNULE1BQUEsQ0FBTyxPQUFQLEVBQWdCLFNBQUMsR0FBRCxHQUFBO0FBQ2QsUUFBQSxJQUFHLEdBQUg7aUJBQ0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0QixHQUE1QixFQUNFO0FBQUEsWUFBQSxXQUFBLEVBQWEsSUFBYjtXQURGLEVBREY7U0FBQSxNQUFBO2lCQUlFLEVBQUUsQ0FBQyxTQUFILENBQWEsT0FBYixFQUFzQixXQUF0QixFQUFtQyxRQUFuQyxFQUpGO1NBRGM7TUFBQSxDQUFoQixFQURTO0lBQUEsQ0E5Q1gsQ0FBQTs7QUFBQSxrQ0FzREEsV0FBQSxHQUFhLFNBQUMsTUFBRCxHQUFBO0FBQ1gsVUFBQSx1Q0FBQTtBQUFBLE1BQUEsSUFBVSxDQUFBLE1BQU8sQ0FBQyxHQUFsQjtBQUFBLGNBQUEsQ0FBQTtPQUFBO0FBQUEsTUFFQSxTQUFBLEdBQVksSUFGWixDQUFBO0FBQUEsTUFHQSxXQUFBLEdBQWMsRUFIZCxDQUFBO0FBQUEsTUFJQSxXQUFBLEdBQ0U7QUFBQSxRQUFBLEtBQUEsRUFBTyxDQUFDLElBQUksQ0FBQyxPQUFMLENBQWEsSUFBSSxDQUFDLE9BQUwsQ0FBYSxNQUFNLENBQUMsSUFBcEIsQ0FBYixDQUFELENBQVA7QUFBQSxRQUNBLFFBQUEsRUFBVSxJQUFJLENBQUMsUUFBTCxDQUFjLE1BQU0sQ0FBQyxJQUFyQixDQURWO0FBQUEsUUFFQSxRQUFBLEVBQWEsTUFBTSxDQUFDLFFBQVAsS0FBbUIsTUFBdEIsR0FBa0MsSUFBbEMsR0FBNEMsS0FGdEQ7QUFBQSxRQUdBLFNBQUEsRUFBYyxNQUFNLENBQUMsU0FBUCxLQUFvQixNQUF2QixHQUFtQyxFQUFuQyxHQUEyQyxLQUh0RDtPQUxGLENBQUE7QUFBQSxNQVVBLEVBQUEsR0FBSyxRQUFRLENBQUMsZUFBVCxDQUNIO0FBQUEsUUFBQSxLQUFBLEVBQU8sRUFBRSxDQUFDLGdCQUFILENBQW9CLE1BQU0sQ0FBQyxJQUEzQixDQUFQO0FBQUEsUUFDQSxRQUFBLEVBQVUsS0FEVjtPQURHLENBVkwsQ0FBQTtBQUFBLE1BY0EsRUFBRSxDQUFDLEVBQUgsQ0FBTSxNQUFOLEVBQWMsU0FBQyxJQUFELEdBQUE7QUFDWixRQUFBLElBQUcsQ0FBQSxTQUFIO0FBQ0UsVUFBQSxXQUFXLENBQUMsSUFBWixDQUFpQixJQUFqQixDQUFBLENBREY7U0FBQTtlQUdBLFNBQUEsR0FBWSxNQUpBO01BQUEsQ0FBZCxDQWRBLENBQUE7YUFvQkEsRUFBRSxDQUFDLEVBQUgsQ0FBTSxPQUFOLEVBQWUsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUEsR0FBQTtpQkFDYixLQUFDLENBQUEsVUFBRCxDQUFZLE1BQVosRUFBb0IsV0FBcEIsRUFBaUMsV0FBakMsRUFEYTtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWYsRUFyQlc7SUFBQSxDQXREYixDQUFBOztBQUFBLGtDQThFQSxVQUFBLEdBQVksU0FBQyxNQUFELEVBQVMsV0FBVCxFQUFzQixXQUF0QixHQUFBO0FBQ1YsTUFBQSxXQUFBLEdBQWMsV0FBVyxDQUFDLElBQVosQ0FBaUIsSUFBakIsQ0FBZCxDQUFBO2FBRUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxXQUFaLEVBQXlCLFdBQXpCLENBQ0UsQ0FBQyxJQURILENBQ1EsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsTUFBRCxHQUFBO0FBQ0osY0FBQSxnQkFBQTtBQUFBLFVBQUEsT0FBQSxHQUFVLElBQUksQ0FBQyxPQUFMLENBQWEsSUFBSSxDQUFDLE9BQUwsQ0FBYSxNQUFNLENBQUMsSUFBcEIsQ0FBYixFQUF3QyxNQUFNLENBQUMsR0FBL0MsQ0FBVixDQUFBO0FBQUEsVUFDQSxPQUFBLEdBQVUsSUFBSSxDQUFDLE9BQUwsQ0FBYSxPQUFiLENBRFYsQ0FBQTtpQkFHQSxLQUFDLENBQUEsVUFBRCxDQUFZLE1BQVosRUFBb0IsT0FBcEIsRUFBNkIsT0FBN0IsRUFKSTtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRFIsRUFNRSxTQUFDLEdBQUQsR0FBQTtBQUNBLFFBQUEsSUFBRyxHQUFIO2lCQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsR0FBRyxDQUFDLE9BQWhDLEVBQ0U7QUFBQSxZQUFBLE1BQUEsRUFBUSxFQUFBLEdBQUcsR0FBRyxDQUFDLFFBQVAsR0FBZ0IsR0FBaEIsR0FBbUIsR0FBRyxDQUFDLElBQS9CO0FBQUEsWUFDQSxXQUFBLEVBQWEsSUFEYjtXQURGLEVBREY7U0FEQTtNQUFBLENBTkYsRUFIVTtJQUFBLENBOUVaLENBQUE7O0FBQUEsa0NBNkZBLFNBQUEsR0FBVyxTQUFDLFFBQUQsRUFBVyxRQUFYLEdBQUE7QUFDVCxVQUFBLEVBQUE7QUFBQSxNQUFBLElBQUcsQ0FBQSxFQUFHLENBQUMsVUFBSCxDQUFjLFFBQWQsQ0FBSjtBQUNFLFFBQUEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0QixFQUFBLEdBQUcsUUFBSCxHQUFZLFlBQXhDLEVBQ0U7QUFBQSxVQUFBLFdBQUEsRUFBYSxJQUFiO1NBREYsQ0FBQSxDQUFBO0FBR0EsY0FBQSxDQUpGO09BQUE7QUFBQSxNQU1BLElBQUMsQ0FBQSxNQUFELEdBQ0U7QUFBQSxRQUFBLElBQUEsRUFBTSxRQUFOO09BUEYsQ0FBQTtBQUFBLE1BU0EsSUFBQyxDQUFBLFNBQUQsR0FBYSxJQVRiLENBQUE7QUFBQSxNQVdBLEVBQUEsR0FBSyxRQUFRLENBQUMsZUFBVCxDQUNIO0FBQUEsUUFBQSxLQUFBLEVBQU8sRUFBRSxDQUFDLGdCQUFILENBQW9CLFFBQXBCLENBQVA7QUFBQSxRQUNBLFFBQUEsRUFBVSxLQURWO09BREcsQ0FYTCxDQUFBO0FBQUEsTUFlQSxFQUFFLENBQUMsRUFBSCxDQUFNLE1BQU4sRUFBYyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxJQUFELEdBQUE7aUJBQ1osS0FBQyxDQUFBLGNBQUQsQ0FBZ0IsSUFBaEIsRUFEWTtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWQsQ0FmQSxDQUFBO2FBa0JBLEVBQUUsQ0FBQyxFQUFILENBQU0sT0FBTixFQUFlLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7QUFDYixVQUFBLElBQUcsS0FBQyxDQUFBLE1BQU0sQ0FBQyxJQUFYO21CQUNFLEtBQUMsQ0FBQSxTQUFELENBQVcsSUFBSSxDQUFDLE9BQUwsQ0FBYSxJQUFJLENBQUMsT0FBTCxDQUFhLFFBQWIsQ0FBYixFQUFxQyxLQUFDLENBQUEsTUFBTSxDQUFDLElBQTdDLENBQVgsRUFBK0QsUUFBL0QsRUFERjtXQUFBLE1BQUE7bUJBR0UsUUFBQSxDQUFTLEtBQUMsQ0FBQSxNQUFWLEVBSEY7V0FEYTtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWYsRUFuQlM7SUFBQSxDQTdGWCxDQUFBOztBQUFBLGtDQXNIQSxjQUFBLEdBQWdCLFNBQUMsSUFBRCxHQUFBO0FBQ2QsTUFBQSxJQUFVLENBQUEsSUFBRSxDQUFBLFNBQVo7QUFBQSxjQUFBLENBQUE7T0FBQTtBQUFBLE1BRUEsSUFBQyxDQUFBLFNBQUQsR0FBYSxLQUZiLENBQUE7YUFJQSxJQUFJLENBQUMsS0FBTCxDQUFXLEdBQVgsQ0FBZSxDQUFDLE9BQWhCLENBQXdCLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLElBQUQsR0FBQTtBQUN0QixjQUFBLG9CQUFBO0FBQUEsVUFBQSxDQUFBLEdBQUksSUFBSSxDQUFDLE9BQUwsQ0FBYSxHQUFiLENBQUosQ0FBQTtBQUVBLFVBQUEsSUFBRyxDQUFBLEdBQUksQ0FBUDtBQUNFLGtCQUFBLENBREY7V0FGQTtBQUFBLFVBS0EsR0FBQSxHQUFNLElBQUksQ0FBQyxNQUFMLENBQVksQ0FBWixFQUFlLENBQWYsQ0FBaUIsQ0FBQyxJQUFsQixDQUFBLENBTE4sQ0FBQTtBQUFBLFVBTUEsS0FBQSxHQUFRLGlCQUFpQixDQUFDLElBQWxCLENBQXVCLEdBQXZCLENBTlIsQ0FBQTtBQVFBLFVBQUEsSUFBRyxLQUFIO0FBQ0UsWUFBQSxHQUFBLEdBQU0sS0FBTSxDQUFBLENBQUEsQ0FBWixDQURGO1dBUkE7QUFBQSxVQVdBLEtBQUEsR0FBUSxJQUFJLENBQUMsTUFBTCxDQUFZLENBQUEsR0FBSSxDQUFoQixDQUFrQixDQUFDLElBQW5CLENBQUEsQ0FYUixDQUFBO2lCQWFBLEtBQUMsQ0FBQSxNQUFPLENBQUEsR0FBQSxDQUFSLEdBQWUsTUFkTztRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXhCLEVBTGM7SUFBQSxDQXRIaEIsQ0FBQTs7K0JBQUE7O01BVEYsQ0FBQTtBQUFBIgp9

//# sourceURL=/C:/Users/Abra%C3%A3o%20Batista/.atom/packages/less-autocompile/lib/less-autocompile-view.coffee
